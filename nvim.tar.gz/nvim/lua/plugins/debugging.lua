-- ~/.config/nvim/lua/plugins/debugging.lua

return {
  "mfussenegger/nvim-dap",
  ft = { "c", "cpp", "cxx", "cc", "h", "hpp", "hxx", "hh" },
  dependencies = {
    "rcarriga/nvim-dap-ui",
    "nvim-neotest/nvim-nio",
    "theHamsta/nvim-dap-virtual-text",
  },
  config = function()
    local dap = require "dap"
    local dapui = require "dapui"

    -- Signs
    vim.fn.sign_define("DapBreakpoint", {
      text = "🔴",
      texthl = "DapBreakpoint",
      linehl = "",
      numhl = "",
    })
    vim.fn.sign_define("DapStopped", {
      text = "🟢",
      texthl = "DapStopped",
      linehl = "Visual",
      numhl = "DiagnosticSignInfo",
    })

    -- Adapter


    dap.adapters.lldb = {
      type = 'executable',
      command = '/usr/local/bin//lldb-vscode',
      name = 'lldb'
    }

    dap.adapters.gdb = {
      type = 'executable',
      command = 'gdb',
      args = {
        -- '--init-command=' .. os.getenv("HOME") .. '/.gdbinit',
        '-q', '-i', 'dap'
        -- '-q', '-i', 'mi2'
      },
    }

    dap.adapters.cppdbg = {
      id = "cppdbg",
      type = "executable",
      command = vim.fn.expand "~/.local/share/vscode-cpptools/extension/extension/debugAdapters/bin/OpenDebugAD7",
      options = {
        detached = false
      }
    }

    -- Configuration

    local lldb_config = {
      {
        name = "LLDB Debug",
        type = "lldb",
        request = "launch",
        program = function()
          local default = vim.fn.getcwd() .. "/build/" .. vim.fn.expand "%:t:r"
          return vim.fn.input("Path to executable: ", default, "file")
        end,
        cwd = vim.fn.getcwd(),
        stopOnEntry = false,
        args = {},
        runInTerminal = true,
        env = function()
          -- Optional: provide environment variables
          return {}
        end,
      }
    }

    -- BUGGED CURRENTLY - DONT USE THIS ONE 
    local gdb_config = {
      {
        name = "GDB: Launch",
        type = "gdb",
        request = "launch",
        program = function()
          return vim.fn.input("Path to executable: ", vim.fn.getcwd() .. "/build/a.out", "file")
        end,
        cwd = vim.fn.getcwd(),
        stopAtEntry = true,
        args = {},
        -- sourceFileMap = {
        --   ["/home/vargamarci97/grappa_homework-skeleton"] = vim.fn.getcwd(),
        -- },
        --
        setupCommands = {
          {
            text = "-enable-pretty-printing",
            description = "Enable pretty printing",
            ignoreFailures = false,
          },
          --           {
          --             text = [[
          --       -interpreter-exec console "python
          -- import sys
          -- sys.path.insert(0, '/usr/share/gcc/python')
          -- from libstdcxx.v6.printers import register_libstdcxx_printers
          -- register_libstdcxx_printers(None)
          -- "
          --     ]],
          --             description = "Load libstdc++ pretty printers",
          --             ignoreFailures = true,
          --           },
        }
        -- setupCommands = {
        --   {
        --     text = "-enable-pretty-printing",
        --     description = "Enable pretty printing",
        --     ignoreFailures = false
        --   },
        -- }
      },
    }

    local cpp_config = {
      {
        name = "Launch file with GDB",
        type = "cppdbg",
        request = "launch",
        program = function()
          local default = vim.fn.getcwd() .. "/build/" .. vim.fn.expand "%:t:r"
          return vim.fn.input("Path to executable: ", default, "file")
        end,
        cwd = vim.fn.getcwd(),
        stopAtEntry = true,
        MIMode = "gdb",
        miDebuggerPath = "/usr/local/bin//gdb",
        -- externalConsole = false,
        externalConsole = true,
        terminal = {
          kind = "external",
          command = "/usr/bin/xterm",
          args = { "-e" }
        },
        -- console = 'integratedTerminal',
        setupCommands = {
          {
            text = "-enable-pretty-printing",
            description = "Enable pretty printing",
            ignoreFailures = false,
          },
          {
            text = [[
              python
              import sys
              sys.path.insert(0, '/usr/share/gcc/python')
              from libstdcxx.v6.printers import register_libstdcxx_printers
              register_libstdcxx_printers(None)
              end
            ]],
            description = "Load libstdc++ pretty printers",
            ignoreFailures = true,
          },
        }
      },
    }

    -- dap.configurations.c = gdb_config
    -- dap.configurations.cpp = gdb_config
    -- dap.configurations.h = gdb_config
    -- dap.configurations.hpp = gdb_config

    -- dap.configurations.c = cpp_config
    -- dap.configurations.cpp = cpp_config
    -- dap.configurations.h = cpp_config
    -- dap.configurations.hpp = cpp_config

    -- dap.configurations.c = lldb_config
    -- dap.configurations.cpp = lldb_config
    -- dap.configurations.h = lldb_config
    -- dap.configurations.hpp = lldb_config

    dap.configurations.cpp = {}
    vim.list_extend(dap.configurations.cpp, cpp_config)
    vim.list_extend(dap.configurations.cpp, lldb_config)
    -- vim.list_extend(dap.configurations.cpp, gdb_config) --BUGGED!!!

    dap.configurations.c = dap.configurations.cpp
    dap.configurations.h = dap.configurations.cpp
    dap.configurations.hpp = dap.configurations.cpp

    -- DAP UI
    dapui.setup {
      layouts = {
        {
          elements = {
            { id = "scopes",      size = 0.33 },
            { id = "breakpoints", size = 0.17 },
            { id = "stacks",      size = 0.25 },
            { id = "watches",     size = 0.25 },
          },
          size = 40,
          position = "left",
        },
        {
          elements = {
            "repl",
            "console",
          },
          size = 10,
          position = "bottom",
        },
      },
      controls = {
        enabled = true,
        element = "repl",
      },
      floating = {
        max_height = 0.3,
        border = "single",
        mappings = {
          close = { "q", "<Esc>" },
        },
      },
      mappings = {
        expand = "<CR>",
        open = "<C-o>",
        close = "<C-c>",
      },
    }

    -- Virtual text
    require("nvim-dap-virtual-text").setup {
      enabled = true,
      enabled_commands = true,
      highlight_changed_variables = true,
      highlight_new_as_changed = true,
    }

    -- Listeners to open/close UI
    dap.listeners.before.attach.dapui_config = function()
      dapui.open()
    end
    dap.listeners.before.launch.dapui_config = function()
      dapui.open()
    end
    dap.listeners.before.event_terminated.dapui_config = function()
      dapui.close()
    end
    dap.listeners.before.event_exited.dapui_config = function()
      dapui.close()
    end

    -- Keybindings
    local map = vim.keymap.set
    -- map("n", "<leader>db", dap.toggle_breakpoint, { desc = "Toggle breakpoint" })
    map("n", "<leader>db", function()
      require("persistent-breakpoints.api").toggle_breakpoint()
    end, { desc = "Toggle persistent breakpoint" })
    map("n", "<leader>dc", dap.continue, { desc = "Continue" })
    map("n", "<leader>dn", dap.step_over, { desc = "Step Over" })
    map("n", "<leader>di", dap.step_into, { desc = "Step Into" })
    map("n", "<leader>do", dap.step_out, { desc = "Step Out" })
    map("n", "<leader>dq", function()
      dap.close()
      dapui.toggle()
    end, { desc = "Quit debugging" })
    map("n", "<leader>dr", dap.restart, { desc = "Restart debug session" })
    map("n", "<leader>dx", function()
      require("persistent-breakpoints.api").clear_all_breakpoints()
      print "🔁 All persistent breakpoints cleared"
    end, { desc = "Clear all breakpoints" })
    -- map("n", "<leader>dx", function()
    --   dap.clear_breakpoints()
    --   print "🔁 Breakpoints cleared"
    -- end, { desc = "Clear all breakpoints" })
    map({ "n", "v" }, "<leader>de", function()
      require("dapui").eval()
    end, { desc = "Eval expression" })
    map("n", "<leader>dL", function()
      local widgets = require "dap.ui.widgets"
      widgets.centered_float(widgets.scopes)
    end, { desc = "Show locals in floating window" })
  end,
}
