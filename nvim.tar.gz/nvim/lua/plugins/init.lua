return {
  {
    "echasnovski/mini.icons",
    version = "*",
  },
  {
    "akinsho/bufferline.nvim",
    version = "*",
    dependencies = "nvim-tree/nvim-web-devicons",
    config = function()
      require("bufferline").setup {}
    end,
  },
  {
    "stevearc/conform.nvim",
    -- event = 'BufWritePre', -- uncomment for format on save
    opts = require "configs.conform",
  },

  -- These are some examples, uncomment them if you want to see them work!
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "configs.lspconfig"
    end,
  },

  {
    "Weissle/persistent-breakpoints.nvim",
    event = "BufReadPost",
    config = function()
      require("persistent-breakpoints").setup {
        load_breakpoints_event = { "BufReadPost" },
      }
    end,
  },
  {
    "s1n7ax/nvim-window-picker",
    name = "window-picker",
    version = "2.*",
    opts = {
      hint = "floating-big-letter", -- visually shows letters/numbers
      -- hint = "statusline-winbar",
      -- selection_chars = 'FJDKSLA;CMRUEIWOQP',
      selection_chars = "0123456789;CMRUEIWOQP",
      show_prompt = false,
    },
  },

  -- test new blink
  -- { import = "nvchad.blink.lazyspec" },

  {
    "nvim-treesitter/nvim-treesitter",
    dependencies = { "OXY2DEV/markview.nvim", "nvim-tree/nvim-web-devicons" },
    opts = {
      ensure_installed = {
        "vim",
        "lua",
        "vimdoc",
        "html",
        "css",
      },
    },
    config = function()
      require("nvim-tree").setup {
        view = {
          width = 35,
          side = "left",
          number = false,
          relativenumber = false,
        },
        actions = {
          open_file = {
            quit_on_open = false, -- Keep tree open after file open
            resize_window = true,
            window_picker = {
              enable = false, -- Open in current window (not new split)
            },
          },
        },
        renderer = {
          group_empty = true,
        },
        git = {
          enable = true,
          ignore = false,
        },
        hijack_cursor = true,
        update_focused_file = {
          enable = true,
          update_root = false,
        },
      }
    end,
  },
  require "plugins.debugging",
}
