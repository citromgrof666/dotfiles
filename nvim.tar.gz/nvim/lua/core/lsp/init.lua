local lspconfig = require("lspconfig")
lspconfig.clangd.setup({
    -- Optional: Adjust configuration for clangd here if necessary
    cmd = { "clangd", "--background-index" },
    filetypes = { "c", "cpp", "objc", "objcpp" },
})
