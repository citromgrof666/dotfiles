require "nvchad.mappings"

-- add yours here

local map = vim.keymap.set

map("n", ";", ":", { desc = "CMD enter command mode" })
map("i", "jk", "<ESC>")

-- Leader + N to switch to window N
vim.keymap.set("n", "<leader>1", ":1wincmd w<CR>", { desc = "Go to window 1" })
vim.keymap.set("n", "<leader>2", ":2wincmd w<CR>", { desc = "Go to window 2" })
vim.keymap.set("n", "<leader>3", ":3wincmd w<CR>", { desc = "Go to window 3" })
vim.keymap.set("n", "<leader>4", ":4wincmd w<CR>", { desc = "Go to window 4" })
vim.keymap.set("n", "<leader>5", ":5wincmd w<CR>", { desc = "Go to window 5" })
vim.keymap.set("n", "<leader>6", ":6wincmd w<CR>", { desc = "Go to window 6" })
vim.keymap.set("n", "<leader>7", ":7wincmd w<CR>", { desc = "Go to window 7" })
vim.keymap.set("n", "<leader>8", ":8wincmd w<CR>", { desc = "Go to window 8" })
vim.keymap.set("n", "<leader>9", ":9wincmd w<CR>", { desc = "Go to window 9" })

-- Leader WW + number - same but with visuals
vim.keymap.set("n", "<leader>ww", function()
  local winid = require("window-picker").pick_window()
  if winid then
    vim.api.nvim_set_current_win(winid)
  end
end, { desc = "Pick window visually" })

-- treesitter
-- vim.keymap.set("n", "<leader>e", ":NvimTreeToggle<CR>", { desc = "Toggle NvimTree" })
vim.keymap.set("n", "<leader>e", function()
  local home = vim.fn.expand("~")
  local git_root = vim.fn.systemlist("git rev-parse --show-toplevel")[1]

  -- Validate if git_root is a directory
  local function is_dir(path)
    local stat = vim.loop.fs_stat(path)
    return stat and stat.type == "directory"
  end

  local root = (git_root and is_dir(git_root)) and git_root or home

  vim.cmd("cd " .. root)
  require("nvim-tree.api").tree.toggle()
end, { desc = "Open NvimTree at Git root or home" })

vim.keymap.set("n", "<C-n>", ":NvimTreeToggle<CR>", { desc = "Toggle NvimTree" })
-- jump between tabs - just press tab, or...
vim.keymap.set("n", "<leader><Right>", ":bnext<CR>", { desc = "Next buffer" })
vim.keymap.set("n", "<leader><Left>", ":bprevious<CR>", { desc = "Previous buffer" })
-- close tab via space+x - already implemented

-- map({ "n", "i", "v" }, "<C-s>", "<cmd> w <cr>")

-- telescope
local builtin = require "telescope.builtin"

vim.keymap.set("n", "<leader>ff", builtin.find_files, { desc = "Find files" })
vim.keymap.set("n", "<leader>fg", builtin.live_grep, { desc = "Live grep" })
vim.keymap.set("n", "<leader>fb", builtin.buffers, { desc = "List buffers" })
vim.keymap.set("n", "<leader>fo", builtin.oldfiles, { desc = "Recent files" })
vim.keymap.set("n", "<leader>fd", builtin.diagnostics, { desc = "Diagnostics" })

-- LSP
vim.keymap.set("n", "<leader>ca", vim.lsp.buf.code_action, { desc = "LSP Code Action" })
vim.api.nvim_set_keymap(
  "n",
  "<leader>fm",
  "<cmd>lua vim.lsp.buf.format({ async = true })<CR>",
  { noremap = true, silent = true, desc = "Format current file" }
)

vim.keymap.set("t", "<Esc>", [[<C-\><C-n>]], { desc = "Exit terminal mode" })
