-- ~/.config/nvim/lua/custom/chadrc.lua
local M = {}

M.plugins = "custom.plugins"
M.mappings = require("custom.mappings")

return M
