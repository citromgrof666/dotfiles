-- ~/.config/nvim/lua/custom/plugins.lua
return {
  {
    "mfussenegger/nvim-dap",
    ft = { "c", "cpp", "cxx", "cc", "h", "hpp", "hxx", "hh" },
    dependencies = {
      "rcarriga/nvim-dap-ui",
      "theHamsta/nvim-dap-virtual-text",
      "nvim-neotest/nvim-nio",
    },
    config = function()
      require("custom.debugging").setup()
    end,
  },

  {
    "rcarriga/nvim-dap-ui",
    dependencies = { "mfussenegger/nvim-dap" },
  },

  {
    'rcarriga/nvim-dap-terminal',
    dependencies = { "mfussenegger/nvim-dap" },
  },

  {
    "stevearc/conform.nvim",
    opts = {
      formatters_by_ft = {
        cpp = { "clang_format" },
        c = { "clang_format" },
        h = { "clang_format" },
        hpp = { "clang_format" },
      },
    },
  },
}
