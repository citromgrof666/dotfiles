return {
  "nvim-treesitter/nvim-treesitter",
  dependencies = { "OXY2DEV/markview.nvim" },
  opts = {
    ensure_installed = {
      "cpp", -- Add C++
      "c", -- Optionally add C if not already there
      -- You can add more languages as needed
    },
  },
}
