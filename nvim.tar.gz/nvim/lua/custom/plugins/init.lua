-- ~/.config/nvim/lua/custom/plugins/init.lua
return {
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "plugins.configs.lspconfig" -- default NvChad LSP config
      require "custom.configs.lspconfig"  -- your custom clangd config
    end,
  },
}

