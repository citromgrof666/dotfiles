return {
  "jose-elias-alvarez/null-ls.nvim",
  config = function()
    local null_ls = require("null-ls")

    null_ls.setup({
      sources = {
        null_ls.builtins.formatting.clang_format,  -- Use clang-format for C++
      },
      -- Optional: auto-format on save
      on_attach = function(client)
        if client.resolved_capabilities.document_formatting then
          vim.cmd([[autocmd BufWritePre <buffer> lua vim.lsp.buf.formatting()]])  -- auto format on save
        end
      end,
    })
  end,
}
