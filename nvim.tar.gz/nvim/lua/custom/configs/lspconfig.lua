local lspconfig = require("lspconfig")

-- Setup clangd for C++
lspconfig.clangd.setup({})

