local null_ls = require("null-ls")

null_ls.setup({
  sources = {
    null_ls.builtins.formatting.clang_format.with({
      extra_args = { "--style=Microsoft" },  -- Optional: Choose your preferred style
    }),
  },
})

-- Optionally, auto-format on save
vim.cmd([[
  autocmd BufWritePre *.cpp,*.h lua vim.lsp.buf.formatting_sync()
]])
