require("nvchad.configs.lspconfig").defaults()

local servers = { "html", "cssls" }
vim.lsp.enable(servers)



vim.lsp.config("clangd", {
  root_markers = { ".clang-format", "compile_commands.json" },
  capabilities = {
    textDocument = {
      completion = {
        completionItem = {
          snippetSupport = true,
        },
      },
    },
  },
})


require('lspconfig').clangd.setup({
  on_attach = function(client, bufnr)
    -- Optional: check if the server supports formatting
    if client.server_capabilities.documentFormattingProvider then
      vim.api.nvim_create_autocmd("BufWritePre", {
        group = vim.api.nvim_create_augroup("LspFormatOnSave", { clear = false }),
        buffer = bufnr,
        callback = function()
          vim.lsp.buf.format({ async = false })
        end,
      })
    end
  end,
})


-- read :h vim.lsp.config for changing options of lsp servers
