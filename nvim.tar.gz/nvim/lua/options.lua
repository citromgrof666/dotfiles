require "nvchad.options"

-- add yours here!

vim.opt.termguicolors = true
-- local o = vim.o
-- o.cursorlineopt ='both' -- to enable cursorline!
