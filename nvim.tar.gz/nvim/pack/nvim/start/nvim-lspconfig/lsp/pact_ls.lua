---@brief
---
--- https://github.com/kadena-io/pact-lsp
---
--- The Pact language server
return {
  cmd = { 'pact-lsp' },
  filetypes = { 'pact' },
  root_markers = { '.git' },
}
